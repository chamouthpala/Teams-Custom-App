﻿//This Controller Created For the Handel the hard coded data.....


using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalApplication.Data;
using FinalApplication.Models;

namespace FinalApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        private readonly DetailCommanderRepo dataRepo = new DetailCommanderRepo();

        [HttpGet]
        public ActionResult<List<Command>> GetDetails()
        {
            var commandItems = dataRepo.GetDetails();

            return Ok(commandItems);

        }

        

        [HttpPost]
        public ActionResult<List<Command>> CreateDetails(List<Command> command)
        {

            var commandNemItem = dataRepo.GetNewDetail(command);
            return Ok(commandNemItem);

        }

        [HttpPut("{id}")]
        public ActionResult UpdateDetails(int id, List<Command> commandU)
        {
            var commandItemU = dataRepo.UpdateDetailById(id, commandU);

            return Ok(commandItemU);


        }

        [HttpDelete("{id}")]
        public ActionResult DeleteDetails(int id)
        {
            var commandDeleteItem = dataRepo.DeleteDetailById(id);

            return Ok(commandDeleteItem);


        }
    }
}
