﻿//This class contains simple Model class to the examples...
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApplication.Models
{
    public class Command
    {
        public int Id { get; set; }
        public string Name { get; set; }

        
    }
}
