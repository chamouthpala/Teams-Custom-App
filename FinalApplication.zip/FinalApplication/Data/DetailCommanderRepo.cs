﻿// In This Data Class initiate some Hard Coded Data to Check API request 
using FinalApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApplication.Data
{
    public class DetailCommanderRepo : Command
    {

        public List<Command> GetDetails()
        {
            var data = new List<Command>
            {
                 new Command { Id = 1, Name = "Uthpala" }, 
                 new Command { Id = 2, Name = "Deshan" },
                 new Command { Id = 3, Name = "Harindi " },
                 new Command { Id = 4, Name = "Hashara" }
                 
            };

            return data;
           
        }

        

        public List<Command> GetNewDetail(List<Command> command)
        {
            var dataN = new List<Command>
            {
                new Command { Id = 1, Name = "Uthpala" },
                 new Command { Id = 2, Name = "Deshan" },
                 new Command { Id = 3, Name = "Harindi " },
                 new Command { Id = 4, Name = "Hashara" }
            };

            dataN.AddRange(command);
            
            return dataN;

        }

        public List<Command> UpdateDetailById(int idU, List<Command> command)
        {

            var dataUpdate = new List<Command>
            {
                 new Command { Id = 1, Name = "Uthpala" },
                 new Command { Id = 2, Name = "Deshan" },
                 new Command { Id = 3, Name = "Harindi " },
                 new Command { Id = 4, Name = "Hashara" }
            };

            for (int i = 0; i < dataUpdate.Count; i++)
            {
                if (dataUpdate[i].Id == idU)
                {
                    dataUpdate.RemoveAt(i);
                    dataUpdate.AddRange(command);

                }
                else
                {
                    Console.WriteLine("ERROR");
                }
            }

            return dataUpdate;

        }

        public List<Command> DeleteDetailById(int idD)
        {
            
            var dataDelete = new List<Command>
            {
                 new Command { Id = 1, Name = "Uthpala" },
                 new Command { Id = 2, Name = "Deshan" },
                 new Command { Id = 3, Name = "Harindi " },
                 new Command { Id = 4, Name = "Hashara" }
            };

            for(int i = 0; i< dataDelete.Count; i++)
            {
                if (dataDelete[i].Id == idD) 
                {
                    dataDelete.RemoveAt(i);

                }
                else
                {
                    Console.WriteLine("ERROR");
                }
            }

            return dataDelete;

        }


    }
}
